package com.parentlock.app

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.security.SecureRandom

class SetupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If already set up → go to main
        val prefs = getSharedPreferences("parentlock", MODE_PRIVATE)
        if (prefs.contains("secret_key")) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_setup)

        val secretDisplay = findViewById<TextView>(R.id.secretDisplay)
        val secretInput   = findViewById<EditText>(R.id.secretInput)
        val confirmBtn    = findViewById<Button>(R.id.confirmBtn)
        val errorText     = findViewById<TextView>(R.id.errorText)

        // Generate random 16-byte secret
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        val secret = bytes.joinToString("") { "%02X".format(it) }
        secretDisplay.text = secret

        confirmBtn.setOnClickListener {
            val entered = secretInput.text.toString().trim().uppercase()
            if (entered == secret) {
                prefs.edit().putString("secret_key", secret).apply()
                Toast.makeText(this, "✓ הגדרה הושלמה!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                errorText.text = "המפתח לא תואם — נסה שוב"
                errorText.visibility = android.view.View.VISIBLE
            }
        }
    }
}
