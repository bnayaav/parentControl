package com.parentlock.app

import android.app.*
import android.content.Intent
import android.os.*
import androidx.core.app.NotificationCompat

class LockService : Service() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = NotificationCompat.Builder(this, "parentlock_channel")
            .setContentTitle("ParentLock פעיל")
            .setContentText("הגנת הורים מופעלת")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "parentlock_channel",
                "ParentLock",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "שמירה על נעילת WhatsApp" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
