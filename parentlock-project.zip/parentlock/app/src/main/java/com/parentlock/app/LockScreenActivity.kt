package com.parentlock.app

import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import java.util.Timer
import java.util.TimerTask

class LockScreenActivity : AppCompatActivity() {

    private var updateTimer: Timer? = null
    private val scope = MainScope()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full screen, always on top
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            WindowManager.LayoutParams.FLAG_FULLSCREEN or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        setContentView(R.layout.activity_lock_screen)

        val prefs = getSharedPreferences("parentlock", MODE_PRIVATE)
        val secretKey = prefs.getString("secret_key", "") ?: ""

        val displayCode  = findViewById<TextView>(R.id.displayCode)
        val timerText    = findViewById<TextView>(R.id.timerText)
        val unlockInput  = findViewById<EditText>(R.id.unlockInput)
        val unlockBtn    = findViewById<Button>(R.id.unlockBtn)
        val errorText    = findViewById<TextView>(R.id.errorText)

        fun refreshCode() {
            scope.launch {
                val code = withContext(Dispatchers.Default) {
                    TOTPHelper.generateChildCode(secretKey)
                }
                displayCode.text = code
            }
        }

        refreshCode()

        // Update countdown every second, refresh code on new window
        var lastWindow = TOTPHelper.getTimeWindow()
        updateTimer = Timer()
        updateTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                runOnUiThread {
                    val remaining = TOTPHelper.getSecondsRemaining()
                    timerText.text = "קוד חדש בעוד ${remaining} שניות"

                    val currentWindow = TOTPHelper.getTimeWindow()
                    if (currentWindow != lastWindow) {
                        lastWindow = currentWindow
                        refreshCode()
                    }
                }
            }
        }, 0, 1000)

        unlockBtn.setOnClickListener {
            val entered = unlockInput.text.toString().trim()
            scope.launch {
                val valid = withContext(Dispatchers.Default) {
                    TOTPHelper.verifyUnlockCode(secretKey, entered)
                }
                if (valid) {
                    LockState.isLocked = false

                    // Log unlock event
                    val log = prefs.getString("unlock_log", "") ?: ""
                    val ts = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault())
                        .format(java.util.Date())
                    prefs.edit().putString("unlock_log", "$log\n$ts — נפתח ע\"י הורה").apply()

                    finish()
                } else {
                    errorText.text = "❌ קוד שגוי — בקש מההורה שוב"
                    errorText.visibility = View.VISIBLE
                    unlockInput.text.clear()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Block back button — child cannot dismiss lock screen
    }

    override fun onDestroy() {
        super.onDestroy()
        updateTimer?.cancel()
        scope.cancel()
    }
}
