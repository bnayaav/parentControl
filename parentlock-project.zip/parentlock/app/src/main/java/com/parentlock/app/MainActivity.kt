package com.parentlock.app

import android.app.ActivityManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("parentlock", MODE_PRIVATE)

        // Start lock service
        val serviceIntent = Intent(this, LockService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(serviceIntent)
        else
            startService(serviceIntent)

        // Status
        val statusText = findViewById<TextView>(R.id.statusText)
        statusText.text = if (LockState.isLocked) "🔒 WhatsApp נעול" else "🔓 WhatsApp פתוח"

        // Lock now button
        findViewById<Button>(R.id.lockNowBtn).setOnClickListener {
            LockState.isLocked = true
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            am.killBackgroundProcesses("com.whatsapp")
            statusText.text = "🔒 WhatsApp נעול"
            Toast.makeText(this, "WhatsApp נעול", Toast.LENGTH_SHORT).show()
        }

        // Show secret key
        val secret = prefs.getString("secret_key", "") ?: ""
        findViewById<TextView>(R.id.secretKeyText).text = "מפתח: $secret"

        // Check accessibility
        if (!isAccessibilityEnabled()) {
            showAccessibilityDialog()
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val service = "${packageName}/${LockAccessibilityService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        return enabled.contains(service)
    }

    private fun showAccessibilityDialog() {
        AlertDialog.Builder(this)
            .setTitle("⚠️ נדרשת הרשאה")
            .setMessage("כדי לנעול את WhatsApp אוטומטית, יש לאפשר שירות נגישות.\n\nלחץ אישור → מצא 'ParentLock' → הפעל")
            .setPositiveButton("פתח הגדרות") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("אחר כך", null)
            .show()
    }
}
