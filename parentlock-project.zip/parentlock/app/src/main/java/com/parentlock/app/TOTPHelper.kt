package com.parentlock.app

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.abs

object TOTPHelper {

    const val PERIOD_SEC = 120L

    fun getTimeWindow(): Long = System.currentTimeMillis() / 1000 / PERIOD_SEC

    fun getSecondsRemaining(): Long {
        val elapsed = (System.currentTimeMillis() / 1000) % PERIOD_SEC
        return PERIOD_SEC - elapsed
    }

    /** 4-digit code displayed to child */
    fun generateChildCode(secretKey: String, window: Long = getTimeWindow()): String {
        val code = hotp(secretKey, "CHILD:$window")
        return (code % 10000).toString().padStart(4, '0')
    }

    /** 6-digit unlock code parent reads out */
    fun generateUnlockCode(secretKey: String, window: Long = getTimeWindow()): String {
        val code = hotp(secretKey, "UNLOCK:$window")
        return (code % 1000000).toString().padStart(6, '0')
    }

    /** Verify unlock code — accept current and previous window (grace) */
    fun verifyUnlockCode(secretKey: String, input: String): Boolean {
        val now = getTimeWindow()
        for (w in listOf(now, now - 1)) {
            if (generateUnlockCode(secretKey, w) == input) return true
        }
        return false
    }

    private fun hotp(keyHex: String, message: String): Long {
        val keyBytes = hexToBytes(keyHex)
        val msgBytes = message.toByteArray(Charsets.UTF_8)
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(keyBytes, "HmacSHA256"))
        val hash = mac.doFinal(msgBytes)
        val offset = (hash.last().toInt() and 0x0f)
        val value = ((hash[offset].toInt() and 0x7f) shl 24) or
                    ((hash[offset + 1].toInt() and 0xff) shl 16) or
                    ((hash[offset + 2].toInt() and 0xff) shl 8) or
                    (hash[offset + 3].toInt() and 0xff)
        return abs(value.toLong())
    }

    private fun hexToBytes(hex: String): ByteArray {
        val result = ByteArray(hex.length / 2)
        for (i in result.indices)
            result[i] = hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        return result
    }
}
