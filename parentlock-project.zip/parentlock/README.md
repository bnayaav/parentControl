# ParentLock — מערכת בקרת הורים ל-WhatsApp

## מה זה?
אפליקציית אנדרואיד שנועלת WhatsApp עם מנגנון קוד TOTP:
- **ילד** רואה 4 ספרות שמתחלפות כל 2 דקות
- **הורה** מכניס את הספרות למחולל ← מקבל קוד פתיחה של 6 ספרות
- ללא שרת, ללא אינטרנט

---

## 🚀 איך לבנות APK דרך GitHub (קל!)

### שלב 1 — צור repo
```bash
git init
git add .
git commit -m "Initial commit"
# צור repo חדש ב-github.com ← לחץ "New repository"
git remote add origin https://github.com/YOUR_USERNAME/parentlock.git
git push -u origin main
```

### שלב 2 — הוסף את gradle-wrapper.jar ⚠️
הקובץ `gradle/wrapper/gradle-wrapper.jar` לא נכלל בגיט (בינארי).
יש להוריד אותו פעם אחת:

```bash
# אפשרות א — הורד מ-GitHub של Gradle:
curl -L "https://raw.githubusercontent.com/gradle/gradle/v8.4.0/gradle/wrapper/gradle-wrapper.jar" \
  -o gradle/wrapper/gradle-wrapper.jar

# אפשרות ב — צור פרויקט ריק ב-Android Studio
# ← העתק את gradle/wrapper/gradle-wrapper.jar לפרויקט הזה

git add gradle/wrapper/gradle-wrapper.jar
git commit -m "Add gradle wrapper"
git push
```

### שלב 3 — GitHub Actions בונה אוטומטית!
1. עבור ל-repo שלך ב-GitHub
2. לחץ על tab **"Actions"**
3. תראה build רץ (כ-3-5 דקות)
4. אחרי שמסיים ← לחץ על ה-run ← גלול למטה ← **Artifacts**
5. הורד **ParentLock-debug-APK**
6. העבר ל-APK למכשיר הילד והתקן

---

## 📱 התקנה במכשיר הילד

1. **העבר APK** לטלפון (דרך Drive / WhatsApp / USB)
2. **אפשר מקורות לא ידועים:**
   - הגדרות → אבטחה → התקן אפליקציות לא ידועות → אפשר
3. **התקן את ה-APK**
4. **פתח ParentLock** — יופיע מפתח סודי
5. **העתק את המפתח** ל-`parent-authenticator.html` (דף ההורה)
6. **הכנס שוב את המפתח** לאישור ← לחץ "אשר והפעל"
7. **אפשר שירות נגישות:**
   - הגדרות → נגישות → שירותים מותקנים → ParentLock → הפעל
8. **סיים!** WhatsApp נעול מעכשיו 🔒

---

## 🔑 שימוש יומיומי

```
ילד פותח WhatsApp
    ↓ נחסם אוטומטית
מסך: 4 ספרות מוצגות (למשל: 3857)
    ↓
ילד אומר להורה: "שלוש שמונה חמש שבע"
    ↓
הורה פותח parent-authenticator.html
מכניס: 3 8 5 7 → לוחץ "אמת"
    ↓
מוצג קוד פתיחה: 041823
    ↓
הורה אומר לילד: "אפס ארבע אחת שמונה שתיים שלוש"
    ↓
ילד מקליד ← WhatsApp נפתח ✓
```

---

## 📁 מבנה הפרויקט

```
parentlock/
├── .github/workflows/build.yml     ← GitHub Actions (בונה APK)
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/parentlock/app/
│       │   ├── SetupActivity.kt     ← הגדרה ראשונית
│       │   ├── MainActivity.kt      ← מסך הורה
│       │   ├── LockScreenActivity.kt← מה שהילד רואה ★
│       │   ├── TOTPHelper.kt        ← לוגיקת הקודים
│       │   ├── LockState.kt         ← מצב נעילה
│       │   ├── LockAccessibilityService.kt ← מיירט WhatsApp
│       │   ├── LockService.kt       ← שומר על פעילות
│       │   └── BootReceiver.kt      ← מתחיל בהפעלה
│       └── res/
│           ├── layout/              ← מסכים
│           ├── xml/                 ← הגדרות נגישות
│           └── values/              ← צבעים, מחרוזות
├── build.gradle
├── settings.gradle
└── gradle/wrapper/
    └── gradle-wrapper.properties
```

---

## ⚠️ פתרון בעיות

| בעיה | פתרון |
|------|--------|
| WhatsApp לא נחסם | הגדרות → נגישות → ParentLock → הפעל |
| האפליקציה נסגרת ברקע | הגדרות → סוללה → ParentLock → "ללא הגבלות" |
| קוד שגוי תמיד | ודא שהמפתח ב-HTML זהה לזה באפליקציה |
| Build נכשל ב-Actions | בדוק שה-gradle-wrapper.jar קיים בגיט |

---

## 🔒 אבטחה
- המפתח הסודי לא יוצא מהמכשיר — אין שרת
- קוד מתחלף כל 2 דקות — לא ניתן לנחש מראש
- עובד ללא אינטרנט לחלוטין
